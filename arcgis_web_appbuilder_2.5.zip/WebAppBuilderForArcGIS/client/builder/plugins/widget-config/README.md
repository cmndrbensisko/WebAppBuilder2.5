* Published events
  * widgetChanged
  * widgetPoolChanged
  * openAtStartChange
  * actionTriggered
  * groupChanged
